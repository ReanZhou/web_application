<template>
  <div>

    <div id="login_content">
      <div class="content_b w1200 clearfix">
        <h2 class="sign_title">Login your account</h2>
        <div class="login_box">
          <h2>Account Details</h2>
          <ul>
            <li><p>Username</p><input v-model="username" placeholder="Username"></li>
            <li><p>Email</p><input v-model="email" placeholder="email"></li>
            <li><p>Password</p><input v-model="password" placeholder="password" type="password"></li>
          </ul>
          <div class="sign_btn">
            <button type="submit" v-on:click="loginUser()">
              Login
            </button>
          </div>
          <div class="shift_to_signup">
            <p>New here? <a href="/sign">Register here</a></p>
          </div>
        </div>

      </div>
    </div>
  </div>


</template>

<script>
  export default {
    data() {
      return {
        error: "",
        errorFlag: false,
        user_id:"",
        username:"",
        email:"",
        password:"",
        token:""
      }
    },
    mounted: function () {


    },
    methods: {
      loginUser: function () {
        if(this.username === "" && this.email === "") {
          alert("You must enter a username or email");
        }
        if(this.password === "") {
          alert("You must enter a password")
        } else {
          if (this.email === "") {
            this.$http.post('http://localhost:4941/api/v1/users/login',JSON.stringify({
              username:this.username,
              password:this.password

            })).then(function (response) {
                this.token = response.data.token;
                this.user_id = response.data.id;
                this.$cookies.set("user_id", this.user_id);
                this.$cookies.set("session", this.token);
                this.$router.push('/');
              }, function (error) {
                if(error.status == 400) {
                  alert("Please enter the true username and password")
                }
                this.error = error;
                this.errorFlag = true;

              })

          }
          if(this.username === ""){
            this.$http.post('http://localhost:4941/api/v1/users/login',JSON.stringify({
              email:this.email,
              password:this.password
            }))
              .then(function (response) {
                this.token = response.data.token;
                this.user_id = response.data.id;
                this.$cookies.set("user_id", this.user_id);
                this.$cookies.set("session", this.token);
                this.$router.push('/');
              }, function (error) {
                if(error.status == 400) {
                  alert("Please enter the true email and password")
                }
                this.error = error;
                this.errorFlag = true;

              })

          }
        }


      }

    }
  }
</script>

<style scoped>

</style>
