import Breadcrumb from './breadcrumb.vue';
import BreadcrumbItem from './breadcrumb-item.vue';

Breadcrumb.Item = BreadcrumbItem;
export default Breadcrumb;