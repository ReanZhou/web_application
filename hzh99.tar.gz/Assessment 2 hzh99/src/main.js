import Vue from 'vue'
import App from './App.vue'
import Home from './Home.vue'
import Users from './Users.vue'
import Login from './Login.vue'
import Sign from './Sign.vue'
import Edit from './Edit.vue'
import Auction from './Auction.vue'
import Detail from './Detail.vue'
import Bid from './Bid.vue'

import VueRouter from 'vue-router';
import VueResource from 'vue-resource';
import VueCookies from 'vue-cookies';
import iView from 'iview/dist/iview.min';
Vue.use(VueRouter);
Vue.use(VueResource);
Vue.use(VueCookies);
Vue.use(iView);

//Vue.http.options.emulateJSON = true;

const routes = [
  {
    path: "/",
    component: Home
  },
  {
    path:"/users/:userId",
    name:"user",
    component: Users
  },
  {
    path: "/users",
    name: "users",
    component: Users
  },
  {
    path: "/login",
    name:"login",
    component:Login
  },
  {
    path:"/sign",
    name:"sign",
    component:Sign
  },
  {
    path:"/edit",
    name:"edit",
    component:Edit
  },

  {
    path:"/auction",
    name:"auction",
    component:Auction
  },
  {
    path:"/auction_detail/:auctionId",
    name:"detail",
    component:Detail
  },
  {
    path:"/bid/:bidId",
    name:"bid",
    component:Bid
  }
];

const router = new VueRouter({
  routes:routes,
  mode: 'history'
});


new Vue({
  el: '#app',
  router: router,
  render: h => h(App)

});
