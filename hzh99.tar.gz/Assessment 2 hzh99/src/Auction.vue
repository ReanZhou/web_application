<template>
  <div class="layout">
    <div class="layout">
      <Layout>
        <Layout>
          <Sider hide-trigger :style="{background: '#fff'}">
            <Menu active-name="1-2" theme="light" width="auto" :open-names="['1']">
              <Submenu name="1">
                <template slot="title">
                  <Icon type="ios-navigate"></Icon>
                  Categorty
                </template>
                <router-link :to="{path:'auction?category-id=1'}"><MenuItem name="1-1">Apparel</MenuItem></router-link>
                <router-link :to="{path:'auction?category-id=2'}"><MenuItem name="1-2">Equipment</MenuItem></router-link>
                <router-link :to="{path:'auction?category-id=3'}"><MenuItem name="1-3">Vehicles</MenuItem></router-link>
                <router-link :to="{path:'auction?category-id=4'}"><MenuItem name="1-4">Property</MenuItem></router-link>
                <router-link :to="{path:'auction?category-id=5'}"><MenuItem name="1-5">Other</MenuItem></router-link>
              </Submenu>
            </Menu>
          </Sider>
          <Layout :style="{padding: '0 24px 24px'}">
            <Breadcrumb :style="{margin: '24px 0'}">
            </Breadcrumb>
            <Content :style="{padding: '24px', minHeight: '280px', background: '#fff'}">
              <form>
                <Input v-model="q" type="text" class="search_in" style="width:300px">
                </Input>
                <Button style="margin-top:16px;margin-left:10px;" type="primary" shape="circle" icon="ios-search" v-on:click="searchAuction()"></Button>
              </form>
                <div v-if="f_flag === true" class="display_box clearfix">
                    <div v-for="auction in auctions"class="dis_img clearfix">
                      <router-link :to="{path:'bid/'+ auction.id}"><p class="fl">{{auction.title}}</p></router-link>
                      <p class="fr">{{auction.endDateTime}}</p>
                      <p class="fr">{{auction.startDateTime}}</p>


                    </div>
                </div>
                <div v-else>
                  <p>No Found</p>
                </div>

            </Content>
          </Layout>
        </Layout>
      </Layout>
    </div>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        error: "",
        errorFlag: false,
        auctions:[],
        category:"",
        q:"",
        f_flag:true,
        first:"",
        url:{}
      }
    },
    mounted: function () {
      this.checkUrl();
      this.firstq();

    },
    methods: {
      firstq:function () {
        this.first = this.$route.query['q'];
        if(this.first !== undefined) {
          this.$http.get("http://localhost:4941/api/v1/auctions?&q=" + this.first)
            .then(function (response) {
              if(response.data.length === 0){
                this.f_flag = false;

              } else {
                for(let i = 0; i<response.data.length; i++) {
                  var mydate2 = new Date(response.data[i].endDateTime);
                  var mydate3 = new Date(response.data[i].startDateTime);
                  response.data[i].startDateTime = mydate3.toLocaleString();
                  response.data[i].endDateTime = mydate2.toLocaleString();
                  this.auctions.push(response.data[i]);
                }
              }

            },function (error) {
              this.error = error;
              this.errorFlag = true;

            })
        }
        if(this.first === undefined){
          this.$http.get("http://localhost:4941/api/v1/auctions?category-id=" + this.$route.query["category-id"])
            .then(function (response) {
              if(response.data.length === 0){
                this.f_flag = false;

              } else {
                for(let i = 0; i<response.data.length; i++) {
                  this.auctions.push(response.data[i]);
                  var mydate2 = new Date(response.data[i].endDateTime);
                  var mydate3 = new Date(response.data[i].startDateTime);
                  response.data[i].startDateTime = mydate3.toLocaleString();
                  response.data[i].endDateTime = mydate2.toLocaleString();
                }
              }

            },function (error) {
              this.error = error;
              this.errorFlag = true;

            })
        }

      },


      checkUrl:function () {
        var url = this.$route.query['category-id'];
        if(url !== undefined){
          return url;
        } else {
          return "";
        }
      },
      searchAuction:function () {
        this.f_flag = false;
        var cid = this.checkUrl();
        if (this.q !== "") {
          if (cid !== "") {
            this.auctions = [];
            this.$http.get("http://localhost:4941/api/v1/auctions?category-id=" + cid + "&q=" + this.q)
              .then(function (response) {
                if (response.data.length === 0) {
                  this.f_flag = false;

                } else {
                  for (let i = 0; i < response.data.length; i++) {
                    var mydate2 = new Date(response.data[i].endDateTime);
                    var mydate3 = new Date(response.data[i].startDateTime);
                    response.data[i].startDateTime = mydate3.toLocaleString();
                    response.data[i].endDateTime = mydate2.toLocaleString();
                    this.auctions.push(response.data[i]);
                    this.f_flag = true;
                  }
                }

              }, function (error) {
                this.error = error;
                this.errorFlag = true;

              })
          }
          if (cid === "") {
            this.auctions = [];
            this.$http.get("http://localhost:4941/api/v1/auctions?q=" + this.q)
              .then(function (response) {
                if (response.data.length === 0) {
                  this.f_flag = false;

                } else {
                  for (let i = 0; i < response.data.length; i++) {
                    var mydate2 = new Date(response.data[i].endDateTime);
                    var mydate3 = new Date(response.data[i].startDateTime);
                    response.data[i].startDateTime = mydate3.toLocaleString();
                    response.data[i].endDateTime = mydate2.toLocaleString();
                    this.auctions.push(response.data[i]);
                    this.f_flag = true;
                  }
                }

              }, function (error) {
                this.error = error;
                this.errorFlag = true;

              })
          }
        } else {
          alert("Please Enter something");
        }


      }


    }
  }
</script>

<style scoped>

</style>
