<template>
  <div>
    <div id="sign_content">
      <div class="content_b w1200 clearfix">
        <h2 class="sign_title">Create a personal account</h2>
        <div class="signup_box">
          <h2>Account Details</h2>
          <ul class="clearfix">
            <li><p>Username</p><input v-model="username" placeholder="Username"></li>
            <li><p>Givenname</p><input v-model="givenname" placeholder="Givenname"></li>
            <li><p>Familyname</p><input v-model="familyname" placeholder="Familyname"></li>
            <li><p>Email</p><input v-model="email" placeholder="email"></li>
            <li><p>Password</p><input v-model="password" placeholder="password"></li>
          </ul>
          <div class="sign_btn">
            <button type="submit" v-on:click="createUser(user)">
              Create
            </button>
          </div>
          <div class="shift_to_login">
            <p>Have an account? <a href="/login">Login in here</a></p>
          </div>

        </div>


      </div>
    </div>
  </div>


</template>

<script>
  export default {
    data() {
      return {
        error: "",
        errorFlag: false,
        users:[],
        username:"",
        givenname:"",
        familyname:"",
        email:"",
        password:""
      }
    },
    mounted: function () {

    },
    methods: {

      createUser:function () {
        if(this.username === ""){
          alert("Please enter a username");
        }
        if(this.email === "") {
          alert("Please enter your email");
        }
        if(this.password === "") {
          alert("Please enter your password");
        }
        else {
          this.$http.post('http://localhost:4941/api/v1/users',JSON.stringify({
            "username":this.username,
            "givenName":this.givenname,
            "familyName":this.familyname,
            "email":this.email,
            "password":this.password

          })).then(function (response) {
            this.$router.push('/login');
          },function (error) {
            this.error = error;
            this.errorFlag = true;

          })
        }


      }

    }
  }
</script>

<style scoped>

</style>
