<template>
  <div>
    <div v-if="this.$cookies.get('session')" class="users">
      <section>

        <div class="modal fade" id="createAuction" tabindex="-1" role="dialog" aria-labelledby="auctionLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h4 class="modal-title" id="auctionLabel">Create your new project</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div class="form-group">
                  <label for="title">Title:</label>
                  <input v-model="title" type="text" class="form-control" id="title">
                </div>
                <br/>
                <div class="form-group">
                  <label>Category:</label>
                  <Select v-model="categoryId" style="width:550px">
                    <Option v-for="item in cList" :value="item.value" :key="item.key" placeholder="choose">{{ item.label }}</Option>
                  </Select>
                </div>
                <br/>
                <div class="form-group">
                  <label for="description">Description:</label>
                  <textarea v-model="description" class="form-control" rows="5" id="description"></textarea>
                </div>
                <br/>
                <div class="form-group">
                  <label>startDate:</label>
                  <Row>
                    <Col span="12">
                    <DatePicker  type="date" placeholder="Select date" style="width: 200px" v-model="startDate" rows="7" ></DatePicker>
                    </Col>
                    <Col span="12">
                    <TimePicker  v-model="startTime" format="HH:mm:ss" placeholder="Select time" style="width: 168px"></TimePicker>
                    </Col>
                  </Row>
                </div>
                <br/>
                <div class="form-group">
                  <label>endDateTime:</label>
                  <Row>
                    <Col span="12">
                    <DatePicker  type="date" placeholder="Select date" style="width: 200px" v-model="endDate" rows="9" ></DatePicker>
                    </Col>
                    <Col span="12">
                    <TimePicker  v-model="endTime" format="HH:mm:ss" placeholder="Select time" style="width: 168px"></TimePicker>
                    </Col>
                  </Row>
                </div>
                <br/>
                <div class="form-group">
                  <label for="reservePrice">ReservePrice:</label>
                  <input v-model="reservePrice" type="number" class="form-control" rows="11" id="reservePrice">
                </div>
                <br/>
                <div class="form-group">
                  <label for="startingBid">startingBid</label>
                  <input v-model="startingBid" type="number" class="form-control" rows="13" id="startingBid">

                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal" v-on:click="createAuction()">
                  Create your Auciton
                </button>
              </div>
            </div>
          </div>
        </div>

      </section>
      <div class="user_content">
        <div class="userinfo w1200">
          <div class="info_b clearfix">
            <h4 class="fl">{{this.users.username}} Detail</h4>
            <p class="edit"><a href="/edit">Edit</a></p>
          </div>
        </div>
        <div class="blank"></div>
        <div class="auction_content">
          <div class="auction_info w1200">
              <ul>
                <li>
                  <table>
                    <thead>Your own Auction
                    <tr>
                      <th>AuctionId</th>
                      <th>Title</th>
                      <th>Cid</th>
                      <th>startDateTime</th>
                      <th>endDateTime</th>
                      <th>reservePrice</th>
                      <th>Bid</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr class="a_list" v-for="auction in own_auction">
                      <td>{{auction.id}}</td>
                      <td>{{auction.title}}</td>
                      <td>{{auction.categoryId}}</td>
                      <td>{{auction.startDateTime}}</td>
                      <td>{{auction.endDateTime}}</td>
                      <td>{{auction.reservePrice}}</td>
                      <td>{{auction.currentBid}}</td>
                      <td><router-link :to="{path:'auction_detail/'+ auction.id}">Detail</router-link></td>

                    </tr>
                    </tbody>
                  </table>
                </li>
              </ul>
          </div>
        </div>
        <div class="blank"></div>
        <div class="userbid_content">
          <div class="userbid_info w1200">
            <ul>
              <li>
                <table>
                  <thead>Your Bid Auction(Processing)
                  <tr>
                    <th>AuctionId</th>
                    <th>Title</th>
                    <th>Cid</th>
                    <th>startDateTime</th>
                    <th>endDateTime</th>
                    <th>reservePrice</th>
                    <th>Bid</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr class="a_list" v-for="bid in bidList">
                    <td>{{bid.id}}</td>
                    <td>{{bid.title}}</td>
                    <td>{{bid.categoryId}}</td>
                    <td>{{bid.startDateTime}}</td>
                    <td>{{bid.endDateTime}}</td>
                    <td>{{bid.reservePrice}}</td>
                    <td>{{bid.currentBid}}</td>
                    <td><router-link :to="{path:'bid/'+ bid.id}">Detail</router-link></td>

                  </tr>
                  </tbody>
                </table>
              </li>
            </ul>

          </div>
          <div class="userbid_info w1200">
            <ul>
              <li>
                <table>
                  <thead>Your Bid Auction(Not Open)
                  <tr>
                    <th>AuctionId</th>
                    <th>Title</th>
                    <th>Cid</th>
                    <th>startDateTime</th>
                    <th>endDateTime</th>
                    <th>reservePrice</th>
                    <th>Bid</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr class="a_list" v-for="bid in bidList2">
                    <td>{{bid.id}}</td>
                    <td>{{bid.title}}</td>
                    <td>{{bid.categoryId}}</td>
                    <td>{{bid.startDateTime}}</td>
                    <td>{{bid.endDateTime}}</td>
                    <td>{{bid.reservePrice}}</td>
                    <td>{{bid.currentBid}}</td>
                    <td><router-link :to="{path:'bid/'+ bid.id}">Detail</router-link></td>

                  </tr>
                  </tbody>
                </table>
              </li>
            </ul>

          </div>
          <div class="userbid_info w1200">
            <ul>
              <li>
                <table v-if="wonList.length != 0">
                  <thead>Your Won Auction
                  <tr>
                    <th>AuctionId</th>
                    <th>Title</th>
                    <th>Cid</th>
                    <th>startDateTime</th>
                    <th>endDateTime</th>
                    <th>reservePrice</th>
                    <th>Bid</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr class="a_list" v-for="bid in wonList">
                    <td>{{bid.id}}</td>
                    <td>{{bid.title}}</td>
                    <td>{{bid.categoryId}}</td>
                    <td>{{bid.startDateTime}}</td>
                    <td>{{bid.endDateTime}}</td>
                    <td>{{bid.reservePrice}}</td>
                    <td>{{bid.currentBid}}</td>
                    <td><router-link :to="{path:'bid/'+ bid.id}">Detail</router-link></td>

                  </tr>
                  </tbody>
                </table>
                <div v-else>
                  <h4>You do not have a won Auction yet</h4>
                </div>
              </li>
            </ul>

          </div>
        </div>
        <div class="blank"></div>
        <button type="button" class="btn_add btn btn-primary" data-toggle="modal"
                data-target="#createAuction" >
          Create new Auction
        </button>
      </div>




    </div>
    <div v-else>
      <div class="login_com">
        <strong>Warning!</strong> You need Login first!
      </div>
    </div>
  </div>


</template>

<script>
  export default {
    data() {
      return {
        error: "",
        errorFlag: false,
        users:"",
        own_auction:[],
        title:"",
        startDate:"",
        startTime:"",
        endDate:"",
        endTime:"",
        categoryId:"",
        description:"",
        startDateTime:'',
        endDateTime:'',
        reservePrice:0,
        startingBid:0,
        bidList:[],
        bidList2:[],
        wonList:[],
        cList: [
          {
            value: 1,
            label: 'Apparel'
          },
          {
            value: 2,
            label: 'Equipment'
          },
          {
            value: 3,
            label: 'Vehicles'
          },
          {
            value: 4,
            label: 'Property'
          },
          {
            value: 5,
            label: 'Other'
          }
        ]

      }
    },
    mounted: function () {
      if(this.$cookies.get('session')) {
        this.getUserInfo();
        this.getUserAt();
        this.getBidinfo();
        this.getwoninfo();
        this.getBidinfo2();
        console.log(this.wonList)
      }
    },
    methods: {
      getUserInfo: function () {
        this.$http.get('http://localhost:4941/api/v1/users/' + this.$cookies.get('user_id'),{
          headers:{
            'X-Authorization': this.$cookies.get("session")
          }
        }).then(function (response) {
          this.users = response.data;

          }, function (error) {
            this.error = error;
            this.errorFlag = true;

        })

      },
      getUserAt: function () {
        this.$http.get('http://localhost:4941/api/v1/auctions?seller=' + this.$cookies.get('user_id')
        ).then(function (response) {
          for(let i = 0; i<response.data.length; i++){
            //alert(response.data[i].);
            this.own_auction.push(response.data[i]);
            var myDate = new Date(response.data[i].startDateTime);
            var mydate2 = new Date(response.data[i].endDateTime);
            response.data[i].startDateTime = myDate.toLocaleString();
            response.data[i].endDateTime = mydate2.toLocaleString();
          }

        }, function (error) {
          this.error = error;
          this.errorFlag = true;

        })

      },
      createAuction:function () {
        if(this.title === ""){
          alert("You must enter your auction title name")
          this.$router.go(this.$router.currentRoute);
        }

        if(this.startDate === ""){
          alert("You must enter your auction startDate")
          this.$router.go(this.$router.currentRoute);
        }

        if(this.endDate === ""){
          alert("You must enter your auction endDate")
          this.$router.go(this.$router.currentRoute);
        }

        if(this.categoryId === ""){
          alert("You must enter your auction category")
          this.$router.go(this.$router.currentRoute);
        }

        if(this.reservePrice === ""){
          alert("You must enter your auction reservePrice")
          this.$router.go(this.$router.currentRoute);
        }

        if(this.startingBid === ""){
          alert("You must enter your auction startingBid")
          this.$router.go(this.$router.currentRoute);
        }


        this.startDate = this.startDate.toISOString().slice(0, 10);
        var str2 = parseInt(this.startDate.slice(-1)) + 1;
        this.startDate = this.startDate.slice(0,9) + str2;
        this.startDateTime = Date.parse(this.startDate + " " + this.startTime);
        this.endDate = this.endDate.toISOString().slice(0, 10);
        var str1 = parseInt(this.endDate.slice(-1)) + 1;
        this.endDate = this.endDate.slice(0,9) + str1;
        this.endDateTime = Date.parse(this.endDate + " " + this.endTime);

        this.$http.post('http://localhost:4941/api/v1/auctions',JSON.stringify({
          "categoryId":parseInt(this.categoryId),
          "title":this.title,
          "description":this.description,
          "startDateTime":this.startDateTime,
          "endDateTime":this.endDateTime,
          "reservePrice":parseInt(this.reservePrice),
          "startingBid":parseInt(this.startingBid)
        }),{
          headers: {
            'X-Authorization': this.$cookies.get("session")
          }
        }).then(function (response) {
          this.$router.go(this.$router.currentRoute);

        },function (error) {
          if(error.status === 400){
            alert(error.statusText);
          }
          this.error = error;
          this.errorFlag = true;

        })
      },
      getBidinfo:function () {
        this.$http.get('http://localhost:4941/api/v1/auctions?status=active&bidder=' + this.$cookies.get('user_id')
        )
          .then(function (response) {
            for(let i = 0; i<response.data.length; i++){
              var myDate = new Date(response.data[i].startDateTime);
              var mydate2 = new Date(response.data[i].endDateTime);
              response.data[i].startDateTime = myDate.toLocaleString();
              response.data[i].endDateTime = mydate2.toLocaleString();
              this.bidList.push(response.data[i]);
            }


          },function (error) {
            this.error = error;
            this.errorFlag = true;

          })

      },
      getBidinfo2:function () {
        this.$http.get('http://localhost:4941/api/v1/auctions?status=upcoming&bidder=' + this.$cookies.get('user_id')
        )
          .then(function (response) {
            for(let i = 0; i<response.data.length; i++){
              var myDate = new Date(response.data[i].startDateTime);
              var mydate2 = new Date(response.data[i].endDateTime);
              response.data[i].startDateTime = myDate.toLocaleString();
              response.data[i].endDateTime = mydate2.toLocaleString();
              this.bidList2.push(response.data[i]);
            }


          },function (error) {
            this.error = error;
            this.errorFlag = true;

          })

      },
      getwoninfo:function () {
        this.$http.get('http://localhost:4941/api/v1/my_won_auctions',{
          headers:{
            'X-Authorization': this.$cookies.get("session")
          }
        })
          .then(function (response) {
            for(let i = 0; i <response.data.length; i++) {
              var myDate = new Date(response.data[i].startDateTime);
              var mydate2 = new Date(response.data[i].endDateTime);
              response.data[i].startDateTime = myDate.toLocaleString();
              response.data[i].endDateTime = mydate2.toLocaleString();
              this.wonList.push(response.data[i]);
            }

          },function (error) {
            this.error = error;
            this.errorFlag = true;

          })

      }


    }
  }
</script>

<style scoped>

</style>
