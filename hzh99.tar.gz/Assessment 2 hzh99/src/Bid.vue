
<template>
  <div>
    <div class="modal fade" id="BidModal" tabindex="-1" role="dialog"
         aria-labelledby="BidModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="BidModalLabel">Bid</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">$times;</span>
            </button>
          </div>
          <div class="modal-body">
            Are you sure that you want to bid to this auction?
            <input v-model="bidnumber" type="number" placeholder="bid number"/>
            <button type="button" class="btn btn-primary" data-dismiss="modal"
                    v-on:click="addBid()">
              Bid
            </button>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
    <div class="detail">
      <div class="detail_content w1200 clearfix">
        <div class="detail_p fl">
          <img :src="this.photo">
        </div>
        <div class="detail_d fl">
          <button type="button" class="btn_edit fl" data-toggle="modal"
                  data-target = "#BidModal">
            Bid
          </button>
          <p class="d_p1 fl">Title:<strong>{{auction.title}}</strong></p>
          <p class="d_p1 fl">CategoryTitle:<strong>{{auction.categoryTitle}}</strong></p>
          <p class="d_p1 fl">StartDateTime:<strong>{{auction.startDateTime}}</strong></p>
          <p class="d_p1 fl">EndDateTime:<strong>{{auction.endDateTime}}</strong></p>
          <p class="d_p1 fl">CurrentBid:<strong>{{auction.currentBid}}</strong></p>
          <p class="d_p1 fl">StartBid:<strong>{{auction.startingBid}}</strong></p>

        </div>
      </div>
      <div class="a_descri w1200">
        <p>Description:<span>{{auction.description}}</span></p>
      </div>
      <div class="bid_list w1200">
        <p>Bid history<input id="show_b" value="show" type="submit" v-on:click="toggle()"></p>

        <div id="bid_lc" v-show="isShow">
          <table>
            <thead>
            <tr>
              <th>Bid Name</th>
              <th>Bid Amount</th>
              <th>Time</th>
            </tr>
            </thead>
            <tbody>
            <tr class="a_list" v-for="bid in bidlist">
              <td>{{bid.buyerUsername}}</td>
              <td>{{bid.amount}}</td>
              <td>{{bid.datetime}}</td>
            </tr>
            </tbody>
          </table>
        </div>

      </div>

      <div>

      </div>

    </div>

  </div>
</template>

<script>
  export default {
    data(){
      return {
        selectFile:null,
        error:"",
        errorFlag:"",
        photo:"",
        ext:"",
        auction:"",
        bidlist:[],
        bidnumber:"",
        name:"image/",
        isShow:true

      }

    },
    mounted:function () {
      if(this.$route.params.bidId) {
        this.getPhoto();
        this.getaAuction();
      }

    },

    methods:{
      toggle:function(){
        this.isShow = !this.isShow;
      },
      getPhoto:function () {
        this.$http.get("http://localhost:4941/api/v1/auctions/"+this.$route.params.bidId+"/photos")
          .then(function (response) {
            this.photo = response.url;
            //response.body.pipe(fs.createWriteStream('../img/' + this.$route.params.auctionId + '.' + this.ext));

          },function (error) {
            this.error = error;
            this.errorFlag = true;

          })

      },
      getaAuction:function () {
        this.$http.get("http://localhost:4941/api/v1/auctions/" + this.$route.params.bidId)
          .then(function (response) {
            var myDate = new Date(response.data.startDateTime);
            var mydate2 = new Date(response.data.endDateTime);
            response.data.startDateTime = myDate.toLocaleString();
            response.data.endDateTime = mydate2.toLocaleString();
            this.auction = response.data;
            for(let i = 0; i<response.data.bids.length; i++) {
              var mydate3 = new Date(response.data.bids[i].datetime);
              response.data.bids[i].datetime = mydate3.toLocaleString();
              this.bidlist.push(response.data.bids[i]);

            }



          },function (error) {
            this.error = error;
            this.errorFlag = true;

          })

      },
      addBid:function () {
        this.$http.post("http://localhost:4941/api/v1/auctions/"+this.$route.params.bidId+"/bids?amount="+this.bidnumber,"",{
          headers: {
            'X-Authorization': this.$cookies.get("session")
          }
        }).then(function (response) {
          this.$router.go(this.$router.currentRoute);

        },function (error) {
          if(error.status === 400) {
            alert("You must bid more than current bid")
          }
          if(error.status === 401) {
            alert("You must login first")
          }
          this.error = error;
          this.errorFlag = true;

        })


      }


    }

  }


</script>


<style scoped>

</style>
