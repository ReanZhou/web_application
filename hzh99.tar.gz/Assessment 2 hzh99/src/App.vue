<template>
  <div id="app">
    <nav id="menu" class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
          <a class="navbar-brand page-scroll" href="/"><i class="fa fa-moon-o fa-rotate-90"></i> Auction</a> </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="/" class="page-scroll">Home</a></li>

            <li><router-link :to="{ name:'users'}">User</router-link></li>
            <li><a href="/login" class="page-scroll">Login</a></li>
            <li v-if="this.$cookies.get('session')" ><a class="page-scroll" v-on:click="logoutUser()">Logout</a></li>
          </ul>
        </div>
        <!-- /.navbar-collapse -->
      </div>
      <!-- /.container-fluid -->
    </nav>
    <router-view></router-view>
    <div id = "footer">
        <div class="footer_content w1200">
          <p>This is the footer of this auction website client</p>

        </div>
    </div>


  </div>
</template>

<script>
  export default {
    data () {
      return{
        errorFlag:false,
        username:"",
        password:"",
        user_id:""
      }
    },
    mounted:function () {

    },
    methods:{
      logoutUser:function () {
        this.$http.post('http://localhost:4941/api/v1/users/logout',"",{
          headers:{
            'X-Authorization': this.$cookies.get("session")
          }
        }).then(function (response) {
          this.$cookies.remove("user_id");
          this.$cookies.remove("session");
          this.$router.go(this.$router.currentRoute);

        },function (error) {
          this.error = error;
          this.errorFlag = true;

        });

      }
    }

  }
</script>

<style>
  #app {
    font-family: 'Avenir', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
    margin-top: 60px;
  }

  h1, h2 {
    font-weight: normal;
  }

  ul {
    list-style-type: none;
    padding: 0;
  }

  li {
    display: inline-block;
    margin: 0 10px;
  }

  a {
    color: #42b983;
  }
</style>
