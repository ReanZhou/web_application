<template>
  <div>
    <section class="section fullscreen-element landing">
      <div class="overlay">
        <div class="overlay-wrapper">
          <div class="overlay-inner bg-black opacity-60"></div>
        </div>
      </div>
      <div class="fullscreen-container">
        <div class="fullscreen-content">
          <div class="container">
            <div class="row">
              <div class="col-md-7 col-lg-8">
                <h1 class="font-white font-65 xs-mb-20 sm-mb-20">The first Auction by hzh99</h1>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <div class="layout">
      <div class="layout">
        <Layout>
          <Layout>
            <Sider hide-trigger :style="{background: '#fff'}">
              <Menu active-name="1-2" theme="light" width="auto" :open-names="['1']">
                <Submenu name="1">
                  <template slot="title">
                    <Icon type="ios-navigate"></Icon>
                    Categorty
                  </template>
                  <router-link :to="{path:'auction?category-id=1'}"><MenuItem name="1-1">Apparel</MenuItem></router-link>
                  <router-link :to="{path:'auction?category-id=2'}"><MenuItem name="1-2">Equipment</MenuItem></router-link>
                  <router-link :to="{path:'auction?category-id=3'}"><MenuItem name="1-3">Vehicles</MenuItem></router-link>
                  <router-link :to="{path:'auction?category-id=4'}"><MenuItem name="1-4">Property</MenuItem></router-link>
                  <router-link :to="{path:'auction?category-id=5'}"><MenuItem name="1-5">Other</MenuItem></router-link>
                </Submenu>
              </Menu>
            </Sider>
            <Layout :style="{padding: '0 24px 24px'}">
              <Breadcrumb :style="{margin: '24px 0'}">
              </Breadcrumb>
              <Content :style="{padding: '24px', minHeight: '280px', background: '#fff'}">
                <form>
                  <Input v-model="q" type="text" class="search_in" style="width:300px">
                  </Input>
                  <Button type="primary" shape="circle" icon="ios-search" v-on:click="makeUrl()"></Button>
                  <div class="home clearfix">
                    <div v-for="auction in auctions" class="home_list fl">
                      <div class="home_img"><img :src="auction.categoryTitle"></div>
                      <router-link :to="{path:'bid/'+ auction.id}"><p>{{auction.title}}</p></router-link></td>
                    </div>

                  </div>
                </form>
              </Content>
            </Layout>
          </Layout>
        </Layout>
      </div>
    </div>


    <div class="login_states">

    </div>

  </div>
</template>

<script>
  export default {
    data() {
      return {
        error: "",
        errorFlag: false,
        auctions:[],
        url:"/auction?",
        category:"",
        q:""
      }
    },
    mounted: function () {
      this.getAuctions();
      console.log(this.auctions)

    },
    methods: {
      makeUrl:function () {
        var q ="q="


        if(this.q !== ""){
          q += this.q;
          this.url += q;
          this.$router.push(this.url);

        } else {
          alert("You must Enter something to start Your search");
        }
        this.url="/auction?"
      },
      getAuctions:function () {
        this.$http.get("http://localhost:4941/api/v1/auctions?count=12&status=active")
          .then(function (auctions) {
            for(let i = 0; i<auctions.data.length;i++){
              let id = auctions.data[i].id;
              this.$http.get("http://localhost:4941/api/v1/auctions/"+id+"/photos")
                .then(function (response) {
                  auctions.data[i].categoryTitle = response.url;

                });
              this.auctions.push(auctions.data[i]);

            }
          },function (error) {
            this.error = error;
            this.errorFlag = true;

          })

      }


    }

  }
</script>

<style scoped>


</style>
