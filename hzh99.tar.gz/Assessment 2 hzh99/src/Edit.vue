<template>
  <div>
    <div id="login_content">
      <div class="content_b w1200 clearfix">
        <h2 class="sign_title">Edit your account</h2>
        <div class="login_box">
          <h2>Account Details</h2>
          <ul>
            <li><p>Username</p><input v-model="username" placeholder="Username"></li>
            <li><p>Givenname</p><input v-model="givenname" placeholder="Givenname"></li>
            <li><p>Familyname</p><input v-model="familyname" placeholder="Familyname"></li>
            <li><p>Email</p><input v-model="email" placeholder="email"></li>
            <li><p>Password</p><input v-model="password" placeholder="password"></li>
          </ul>
          <div class="sign_btn">
            <button type="submit" v-on:click="editUser()">
              Submit
            </button>
          </div>
        </div>

      </div>
    </div>

  </div>

</template>

<script>
    export default {
      data(){
          return{
            error:"",
            errorFlag:false,
            username:"",
            givenname:"",
            familyname:"",
            email:"",
            password:"",
            userid:""
          }
      },
      mounted:function () {


      },
      methods:{
        editUser:function () {
          this.userid = this.$cookies.get('user_id');
          this.$http.patch('http://localhost:4941/api/v1/users/' + this.userid,JSON.stringify({
              "username":this.username,
              "givenName":this.givenname,
              "familyName":this.familyname,
              "email":this.email,
              "password":this.password

          }),{
            headers: {
              'X-Authorization': this.$cookies.get("session")
            }
          }).then(function (reponse) {
            this.$router.push('/');


          },function (error) {
            this.error = error;
            this.errorFlag = true;

          })


        }
      }


    }
</script>

<style scoped>

</style>
