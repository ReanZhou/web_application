
<template>
<div>
  <div class="modal fade" id="EditAuction" tabindex="-1" role="dialog" aria-labelledby="EditauctionLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title" id="EditauctionLabel">Create your new project</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label for="title">Title:</label>
            <input v-model="title" type="text" class="form-control" id="title">
          </div>
          <br/>
          <div class="form-group">
            <label>CategoryId:</label>
            <Select v-model="categoryId" style="width:550px">
              <Option v-for="item in cList" :value="item.value" :key="item.key" placeholder="choose">{{ item.label }}</Option>
            </Select>
          </div>
          <br/>
          <div class="form-group">
            <label for="description">Description:</label>
            <textarea v-model="description" class="form-control" rows="5" id="description"></textarea>
          </div>
          <br/>
          <div class="form-group">
            <label>startDate:</label>
            <Row>
              <Col span="12">
              <DatePicker  type="date" placeholder="Select date" style="width: 200px" v-model="startDate" rows="7" ></DatePicker>
              </Col>
              <Col span="12">
              <TimePicker  v-model="startTime" format="HH:mm:ss" placeholder="Select time" style="width: 168px"></TimePicker>
              </Col>
            </Row>

          </div>
          <br/>
          <div class="form-group">
            <label>endDateTime:</label>
            <Row>
              <Col span="12">
              <DatePicker  type="date" placeholder="Select date" style="width: 200px" v-model="endDate" rows="9" ></DatePicker>
              </Col>
              <Col span="12">
              <TimePicker  v-model="endTime" format="HH:mm:ss" placeholder="Select time" style="width: 168px"></TimePicker>
              </Col>
            </Row>
          </div>
          <br/>
          <div class="form-group">
            <label for="reservePrice">ReservePrice:</label>
            <input v-model="reservePrice" type="number" class="form-control" rows="11" id="reservePrice">
          </div>
          <br/>
          <div class="form-group">
            <label for="startingBid">startingBid</label>
            <input v-model="startingBid" type="number" class="form-control" rows="13" id="startingBid">

          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal" v-on:click="editAuction()">
            Edit your Auciton
          </button>
        </div>
      </div>
    </div>
  </div>
  <div class="detail">
    <div class="detail_content w1200 clearfix">
      <div class="detail_p fl">
        <img :src="this.photo">
      </div>
      <div class="detail_d fl" >
        <button type="button" class="btn_edit fl" data-toggle="modal"
                data-target = "#EditAuction" v-if="new Date().toLocaleString() < auction.startDateTime">
          Edit
        </button>
        <button type="button" class="btn_edit fl" v-on:click="DeleteP()" v-if="new Date().toLocaleString() < auction.startDateTime">
          DeletePhoto
        </button>
        <p class="d_p1 fl">Title:<strong>{{auction.title}}</strong></p>
        <p class="d_p1 fl">CategoryTitle:<strong>{{auction.categoryTitle}}</strong></p>
        <p class="d_p1 fl">StartDateTime:<strong>{{auction.startDateTime}}</strong></p>
        <p class="d_p1 fl">EndDateTime:<strong>{{auction.endDateTime}}</strong></p>
        <p class="d_p1 fl">CurrentBid:<strong>{{auction.currentBid}}</strong></p>
        <p class="d_p1 fl">StartBid:<strong>{{auction.startingBid}}</strong></p>

      </div>
    </div>
    <div class="a_descri w1200">
      <p>Description:<span>{{auction.description}}</span></p>
    </div>
    <div class="bid_list w1200">
      <p>Bid history<input id="show_b" value="hide" type="submit" v-on:click="toggle()"></p>

      <div id="bid_lc" v-show="isShow">
        <table>
          <thead>
          <tr>
            <th>Bid Name</th>
            <th>Bid Amount</th>
            <th>Time</th>
          </tr>
          </thead>
          <tbody>
          <tr class="a_list" v-for="bid in bidlist">
            <td>{{bid.buyerUsername}}</td>
            <td>{{bid.amount}}</td>
            <td>{{bid.datetime}}</td>
          </tr>
          </tbody>
        </table>
      </div>
      <div class="edit_a w1200 clearfix">
        <input ref="files" type="file" name="avatar" id="img" v-on:change="onFileSelected" class="fl" >
        <button @click="addPhoto()" class="addp fl">
          Upload
        </button>
        <span @click='delete_img(index)' class="addp fl">Delete</span>

      </div>
      <div class="preview">
        <img :src=imgs>

      </div>

    </div>



    <div>

    </div>

  </div>

</div>
</template>

<script>
    export default {
        data(){
          return {
            selectFile:null,
            error:"",
            errorFlag:"",
            photo:"",
            ext:"",
            auction:"",
            bidlist:[],
            bidnumber:"",
            title:"",
            startDate:"",
            startTime:"",
            endDate:"",
            endTime:"",
            categoryId:"",
            description:"",
            startDateTime:'',
            endDateTime:'',
            reservePrice:"",
            startingBid:"",
            imgs:"",
            isShow:true,
            cList: [
              {
                value: 1,
                label: 'Apparel'
              },
              {
                value: 2,
                label: 'Equipment'
              },
              {
                value: 3,
                label: 'Vehicles'
              },
              {
                value: 4,
                label: 'Property'
              },
              {
                value: 5,
                label: 'Other'
              }
            ]

          }

        },
      mounted:function () {
          if(this.$route.params.auctionId) {
            this.getPhoto();
            this.getaAuction();

          }

      },

      methods:{

        toggle:function(){
          this.isShow = !this.isShow;
        },

          getPhoto:function () {
            this.$http.get("http://localhost:4941/api/v1/auctions/"+this.$route.params.auctionId+"/photos")
              .then(function (response) {
                this.photo = response.url;
              },function (error) {
                this.error = error;
                this.errorFlag = true;

              })

          },
        getaAuction:function () {
          this.$http.get("http://localhost:4941/api/v1/auctions/" + this.$route.params.auctionId)
            .then(function (response) {
              var myDate = new Date(response.data.startDateTime);
              var mydate2 = new Date(response.data.endDateTime);
              response.data.startDateTime = myDate.toLocaleString();
              response.data.endDateTime = mydate2.toLocaleString();
              this.auction = response.data;
              for(let i = 0; i<response.data.bids.length; i++) {
                var mydate3 = new Date(response.data.bids[i].datetime);
                response.data.bids[i].datetime = mydate3.toLocaleString();
                this.bidlist.push(response.data.bids[i]);

              }



            },function (error) {
              this.error = error;
              this.errorFlag = true;

            })

        },
        editAuction:function () {
          var values = {};
          if(this.startDate != "") {
            this.startDate = this.startDate.toISOString().slice(0, 10);
            var str2 = parseInt(this.startDate.slice(-1)) + 1;
            this.startDate = this.startDate.slice(0,9) + str2;
            this.startDateTime = Date.parse(this.startDate + " " + this.startTime);
            values["startDateTime"] = this.startDateTime;
          }

          if(this.endDate != "") {
            this.endDate = this.endDate.toISOString().slice(0, 10);
            var str1 = parseInt(this.endDate.slice(-1)) + 1;
            this.endDate = this.endDate.slice(0,9) + str1;
            this.endDateTime = Date.parse(this.endDate + " " + this.endTime);
            values["endDateTime"] = this.endDateTime;
          };

          if(this.categoryId != null && this.categoryId != 0) {
            values["categoryId"] = this.categoryId;
          }

          if(this.description != "") {
            values["description"] = this.description;
          }

          if(this.title != "" || this.title != undefined) {
            values["title"] = this.title;
          }

          if(this.reservePrice != "") {
            values["reservePrice"] = parseInt(this.reservePrice);
          }
          if(this.startingBid != "") {
            values["startingBid"] = parseInt(this.startingBid);
           }


          this.$http.patch('http://localhost:4941/api/v1/auctions/'+ this.$route.params.auctionId,JSON.stringify(values),{
            headers: {
              'X-Authorization': this.$cookies.get("session")
            }
          }).then(function (response) {
            this.$router.go(this.$router.currentRoute);

          },function (error) {
            this.error = error;
            this.errorFlag = true;

          })

        },
        delete_img(e){
          this.imgs="";
        },
        onFileSelected:function(event) {
          let vm = this;
          var reader =new FileReader();

          vm.file = event.target.files[0] || event.dataTransfer.files[0];
          reader.readAsDataURL(vm.file);
          reader.onloadend=function(){
            vm.imgs = reader.result;
          };
          reader.readAsDataURL(vm.file);
        },

        addPhoto:function () {
          let vm = this;
          //this.selectFile = document.getElementById('img').files[0];
          //const fd = new FormData();
          const headers = {
            headers: {
              'Content-Type': vm.file.type,
              'X-Authorization': this.$cookies.get("session")}
          };
          //fd.append('image',this.selectFile,this.selectFile.name);


          this.$http.post("http://localhost:4941/api/v1/auctions/" +this.$route.params.auctionId +"/photos",vm.file,headers)
            .then(function (response) {
              this.$router.go(this.$router.currentRoute);

            },function (error) {
              this.error = error;
              this.errorFlag = true;

            })

        },
        DeleteP:function () {
          const headers = {
            headers: {
              'X-Authorization': this.$cookies.get("session")}
          };
          this.$http.delete("http://localhost:4941/api/v1/auctions/" +this.$route.params.auctionId +"/photos",headers)
            .then(function (response) {
              this.$router.go(this.$router.currentRoute);

            },function (error) {
              this.error = error;
              this.errorFlag = true;

            })


        }

      }


    }


</script>


<style scoped>

</style>
